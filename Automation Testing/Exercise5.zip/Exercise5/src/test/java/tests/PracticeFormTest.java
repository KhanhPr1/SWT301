package tests;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import pages.PracticeFormPage;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("Practice Form Registration Tests")
public class PracticeFormTest extends BaseTest {
    static PracticeFormPage page;

    @BeforeAll
    static void init() {
        page = new PracticeFormPage(driver);
    }

    @Test
    @Order(1)
    @DisplayName("Single hard-coded registration")
    void testSingleRegistration() {
        page.navigate();
        page.setFirstName("Daniel Alexandru");
        page.setLastName("Vlasceanu");
        page.setEmail("ps5@yahoo.ro");
        page.selectGender("Male");
        page.setMobile("0741223451");
        page.setDateOfBirth("23", "June", "1980");
        page.addSubject("Arts");
        page.selectHobby("Sports");
        page.selectHobby("Music");
        page.setAddress("Str. Hohoho");
        page.selectStateAndCity("Uttar Pradesh", "Agra");
        page.submitForm();

        page.waitForModal();
        assertEquals("Daniel Alexandru Vlasceanu", page.getSubmissionValue("Student Name"));
        assertEquals("ps5@yahoo.ro",              page.getSubmissionValue("Student Email"));
        assertEquals("Male",                      page.getSubmissionValue("Gender"));
        assertEquals("0741223451",                page.getSubmissionValue("Mobile"));
        assertEquals("23 June,1980",              page.getSubmissionValue("Date of Birth"));
        assertEquals("Arts",                      page.getSubmissionValue("Subjects"));
        assertEquals("Sports, Music",             page.getSubmissionValue("Hobbies"));
        assertEquals("Str. Hohoho",               page.getSubmissionValue("Address"));
        assertEquals("Uttar Pradesh Agra",        page.getSubmissionValue("State and City"));

        page.closeModal();
    }

    @ParameterizedTest(name = "[{index}] {0} {1}")
    @Order(2)
    @CsvFileSource(resources = "/practice-form-data.csv", numLinesToSkip = 1)
    @DisplayName("Data-driven registration (CSV)")
    void testRegistrationFromCsv(
            String first, String last,
            String email, String gender,
            String mobile, String day, String month, String year,
            String subject,
            String hobby1, String hobby2,
            String address, String state, String city
    ) {
        page.navigate();
        page.setFirstName(first);
        page.setLastName(last);
        page.setEmail(email);
        page.selectGender(gender);
        page.setMobile(mobile);
        page.setDateOfBirth(day, month, year);
        page.addSubject(subject);
        page.selectHobby(hobby1);
        page.selectHobby(hobby2);
        page.setAddress(address);
        page.selectStateAndCity(state, city);
        page.submitForm();

        page.waitForModal();
        assertEquals(first + " " + last, page.getSubmissionValue("Student Name"));
        assertEquals(email,               page.getSubmissionValue("Student Email"));
        assertEquals(gender,              page.getSubmissionValue("Gender"));
        assertEquals(mobile,              page.getSubmissionValue("Mobile"));
        assertEquals(day + " " + month + "," + year,
                page.getSubmissionValue("Date of Birth"));
        assertEquals(subject,             page.getSubmissionValue("Subjects"));
        assertEquals(hobby1 + ", " + hobby2,
                page.getSubmissionValue("Hobbies"));
        assertEquals(address,             page.getSubmissionValue("Address"));
        assertEquals(state + " " + city,
                page.getSubmissionValue("State and City"));

        page.closeModal();
    }
}
