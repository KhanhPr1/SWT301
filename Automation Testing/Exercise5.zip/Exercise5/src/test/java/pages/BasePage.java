package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected JavascriptExecutor js;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js     = (JavascriptExecutor) driver;
    }

    protected WebElement waitForVisibility(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Click + scroll into view để tránh bị che
     */
    protected void click(By locator) {
        WebElement el = waitForClickable(locator);
        js.executeScript("arguments[0].scrollIntoView(true);", el);
        el.click();
    }

    protected void type(By locator, String text) {
        WebElement el = waitForVisibility(locator);
        el.clear();
        el.sendKeys(text);
    }

    protected void selectByVisibleText(By locator, String text) {
        WebElement el = waitForVisibility(locator);
        new org.openqa.selenium.support.ui.Select(el).selectByVisibleText(text);
    }

    protected void navigateTo(String url) {
        driver.get(url);
    }


    protected void hideFixedBan() {
        js.executeScript(
                "var b = document.getElementById('fixedban'); if(b) b.style.display='none';"
        );
    }
}
