package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class PracticeFormPage extends BasePage {
    public PracticeFormPage(WebDriver driver) {
        super(driver);
    }

    // --- locators ---
    private By firstNameInput   = By.id("firstName");
    private By lastNameInput    = By.id("lastName");
    private By emailInput       = By.id("userEmail");
    private By genderOption(String gender) {
        return By.xpath("//label[text()='" + gender + "']");
    }
    private By mobileInput      = By.id("userNumber");

    private By dateOfBirthInput = By.id("dateOfBirthInput");
    private By monthSelect      = By.className("react-datepicker__month-select");
    private By yearSelect       = By.className("react-datepicker__year-select");
    private By dayOption(String day) {
        return By.xpath(
                "//div[contains(@class,'react-datepicker__day') " +
                        "and text()='" + day + "' " +
                        "and not(contains(@class,'--outside-month'))]"
        );
    }

    private By subjectsInput    = By.id("subjectsInput");
    private By subjectChoice(String subject) {
        return By.xpath("//div[@id='subjectsContainer']//div[text()='" + subject + "']");
    }

    private By hobbyOption(String hobby) {
        return By.xpath("//label[text()='" + hobby + "']");
    }

    private By addressInput     = By.id("currentAddress");

    private By stateDropdown    = By.id("state");
    private By stateInput       = By.id("react-select-3-input");
    private By cityDropdown     = By.id("city");
    private By cityInput        = By.id("react-select-4-input");

    private By submitButton     = By.id("submit");

    // modal
    private By modalTitle       = By.id("example-modal-sizes-title-lg");
    private By submittedValue(String label) {
        return By.xpath("//td[text()='" + label + "']/following-sibling::td");
    }
    private By closeModalButton = By.id("closeLargeModal");

    // --- actions ---
    public void navigate() {
        navigateTo("https://demoqa.com/automation-practice-form");
        hideFixedBan();      // <-- ẩn banner ngay sau khi load
    }

    public void setFirstName(String first)    { type(firstNameInput, first); }
    public void setLastName(String last)      { type(lastNameInput,  last); }
    public void setEmail(String email)        { type(emailInput,      email); }
    public void selectGender(String g)        { click(genderOption(g)); }
    public void setMobile(String m)           { type(mobileInput,     m); }

    /** Chọn ngày sinh bằng dropdown và click ngày */
    public void setDateOfBirth(String day, String month, String year) {
        click(dateOfBirthInput);
        selectByVisibleText(monthSelect, month);
        selectByVisibleText(yearSelect,  year);
        click(dayOption(day));
    }

    public void addSubject(String subject) {
        type(subjectsInput, subject);
        driver.findElement(subjectsInput).sendKeys(Keys.ENTER);
        waitForVisibility(subjectChoice(subject));
    }

    public void selectHobby(String hobby) { click(hobbyOption(hobby)); }
    public void setAddress(String addr)   { type(addressInput, addr); }

    public void selectStateAndCity(String state, String city) {
        click(stateDropdown);
        type(stateInput, state);
        driver.findElement(stateInput).sendKeys(Keys.ENTER);

        click(cityDropdown);
        type(cityInput, city);
        driver.findElement(cityInput).sendKeys(Keys.ENTER);
    }

    public void submitForm()              { click(submitButton);    }
    public void waitForModal()            { waitForVisibility(modalTitle); }
    public String getSubmissionValue(String label) {
        return waitForVisibility(submittedValue(label)).getText();
    }
    public void closeModal()              { click(closeModalButton); }
}
