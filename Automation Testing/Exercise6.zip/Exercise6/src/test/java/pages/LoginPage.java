package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {
    private final String url        = "http://localhost:9999/Exercise_6/login.jsp";
    private final By txtUsername    = By.name("username");
    private final By txtPassword    = By.name("password");
    private final By btnLogin       = By.xpath("//button[text()='Login']");
    private final By successLocator = By.xpath("//*[contains(text(),'Welcome,')]");
    private final By errorLocator   = By.xpath("//*[contains(text(),'Invalid credentials')]");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void navigate() {
        navigateTo(url);
    }

    public void login(String u, String p) {
        type(txtUsername, u);
        type(txtPassword, p);
        click(btnLogin);
    }

    public By getSuccessLocator() { return successLocator; }
    public By getErrorLocator()   { return errorLocator; }
}
