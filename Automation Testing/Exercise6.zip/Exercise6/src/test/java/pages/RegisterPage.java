package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage extends BasePage {
    private static final String REGISTER_URL   = "http://localhost:9999/Exercise_6/register.jsp";
    private final By txtUsername              = By.name("username");
    private final By txtPassword              = By.name("password");
    private final By btnRegister              = By.xpath("//button[text()='Register']");

    private final By successLocator           = By.xpath("//div[@style='color:green']");

    private final By errorLocator             = By.xpath("//div[@style='color:red']");

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    public void navigate() {
        navigateTo(REGISTER_URL);
    }

    public void register(String user, String pass) {
        type(txtUsername, user);
        type(txtPassword, pass);
        click(btnRegister);
    }

    public By getSuccessLocator() { return successLocator; }
    public By getErrorLocator()   { return errorLocator;   }
}
