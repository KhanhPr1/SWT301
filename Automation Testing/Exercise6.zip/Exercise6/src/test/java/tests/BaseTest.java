package tests;

import org.junit.jupiter.api.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.DriverFactory;

import java.time.Duration;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public abstract class BaseTest {
    protected WebDriver driver;
    protected WebDriverWait wait;

    @BeforeAll
    public void setUpBase() {
        driver = DriverFactory.createDriver();
        driver.manage().window().maximize();
        wait   = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @AfterAll
    public void tearDownBase() {
        if (driver != null) {
            driver.quit();
        }
    }
}
