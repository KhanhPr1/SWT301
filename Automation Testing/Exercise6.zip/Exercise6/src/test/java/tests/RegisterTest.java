package tests;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.RegisterPage;

import static org.junit.jupiter.api.Assertions.*;


public class RegisterTest extends BaseTest {

    @ParameterizedTest(name = "[{index}] register {0}/{1} ⇒ {2}")
    @CsvFileSource(resources = "/register-data.csv", numLinesToSkip = 1)
    public void registerFromCsv(String rawUser, String rawPass, String expected) {
        String user = rawUser   == null ? "" : rawUser.trim();
        String pass = rawPass   == null ? "" : rawPass.trim();
        expected    = expected.trim();

        RegisterPage page = new RegisterPage(driver);
        page.navigate();
        page.register(user, pass);

        if (expected.equals("success")) {
            assertTrue(
                    wait.until(ExpectedConditions
                                    .visibilityOfElementLocated(page.getSuccessLocator()))
                            .getText()
                            .contains("Registration successful"),
                    "Expected success message after register"
            );
        } else {
            String msg = wait.until(ExpectedConditions
                            .visibilityOfElementLocated(page.getErrorLocator()))
                    .getText()
                    .toLowerCase();
            assertTrue(
                    msg.contains("error"),
                    "Expected error message on register, but was: " + msg
            );
        }
    }
}
