package tests;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.LoginPage;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoginTest extends BaseTest {

    @ParameterizedTest(name = "[{index}] login {0}/{1} → {2}")
    @CsvFileSource(resources = "/login-data.csv", numLinesToSkip = 1)
    public void loginFromCsv(String username, String password, String expected) {
        // normalize inputs
        username = username == null ? "" : username.trim();
        password = password == null ? "" : password.trim();
        expected = expected.trim();

        // instantiate with driver
        LoginPage page = new LoginPage(driver);
        page.navigate();
        page.login(username, password);

        // decide which locator to use
        By locator = expected.equals("success")
                ? page.getSuccessLocator()
                : page.getErrorLocator();

        WebElement msg = wait.until(
                ExpectedConditions.visibilityOfElementLocated(locator)
        );

        if (expected.equals("success")) {
            assertTrue(
                    msg.getText().contains("Welcome,"),
                    "Expected success message but was: " + msg.getText()
            );
        } else {
            assertTrue(
                    msg.getText().toLowerCase().contains("invalid"),
                    "Expected error message but was: " + msg.getText()
            );
        }
    }
}
