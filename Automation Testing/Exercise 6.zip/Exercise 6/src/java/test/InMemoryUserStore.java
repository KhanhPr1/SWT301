package test;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class InMemoryUserStore {
    private static final ConcurrentMap<String, String> USERS = new ConcurrentHashMap<>();

    static {
        // default user must match test form: tomsmith/12345678
        USERS.put("tomsmith", "12345678");
    }

    /** Register new user; return false if username already exists */
    public static boolean register(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        return USERS.putIfAbsent(username, password) == null;
    }

    /** Validate login */
    public static boolean validate(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        String stored = USERS.get(username);
        return password.equals(stored);
    }
}
