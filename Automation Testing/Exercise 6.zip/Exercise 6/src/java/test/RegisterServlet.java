package test;

import test.InMemoryUserStore;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import test.InMemoryUserStore;

@WebServlet(name="RegisterServlet", urlPatterns={"/register"})
public class RegisterServlet extends HttpServlet {
  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    String u = req.getParameter("username");
    String p = req.getParameter("password");

    boolean validUsername = u != null && u.matches("[A-Za-z0-9]{6,12}");
    boolean validPassword = p != null && p.matches("\\d{8,12}");

    if (!validUsername || !validPassword) {
      req.setAttribute("error", "Error: Invalid registration data");
      req.getRequestDispatcher("register.jsp").forward(req, resp);
      return;
    }

    boolean ok = InMemoryUserStore.register(u, p);
    if (ok) {
      // **FORWARD** back to register.jsp with success
      req.setAttribute("success", "Registration successful");
      req.getRequestDispatcher("register.jsp").forward(req, resp);
    } else {
      req.setAttribute("error", "Error: Username already exists");
      req.getRequestDispatcher("register.jsp").forward(req, resp);
    }
  }
}

